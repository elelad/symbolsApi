module.exports = {
    mlabUrl : 'mongodb://elad:elad@ds247047.mlab.com:47047/symbols-test',
    mlabUrlNew : 'mongodb://elad:elad@ds155699.mlab.com:55699/symbolsapi',
    //url : 'mongodb://localhost:27017/symbols-test'
    url: 'mongodb://symbotalk:symbotalk@symbolsdb-shard-00-00-y8hyj.mongodb.net:27017,symbolsdb-shard-00-01-y8hyj.mongodb.net:27017,symbolsdb-shard-00-02-y8hyj.mongodb.net:27017/test?ssl=true&replicaSet=SymbolsDB-shard-0&authSource=admin'
    
  };